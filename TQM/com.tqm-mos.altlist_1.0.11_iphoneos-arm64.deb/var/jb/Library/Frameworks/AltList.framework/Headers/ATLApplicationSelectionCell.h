#import <Preferences/PSTableCell.h>

@interface ATLApplicationSelectionCell : PSTableCell

@end