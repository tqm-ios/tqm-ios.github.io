#import <LocalAuthentication/LAContext.h>
#import <Foundation/Foundation.h>
#import "MobileGestalt.h"
#import <UIKit/UIKit.h>
#import <sys/utsname.h>
#import <sys/sysctl.h>
#import <spawn.h>

@interface PHXDevice : NSObject
+ (BOOL)isNotched;
+ (CGFloat)deviceVersion;
+ (NSString *)deviceName;
+ (NSString *)deviceType;
+ (NSString *)deviceModel;
+ (NSString *)deviceUptime;
+ (NSString *)deviceUDID;
+ (NSString *)deviceTheme;
+ (NSString *)deviceOrientation;
+ (NSString *)landscapeType;
+ (NSString *)statusBarOrientation;
@end