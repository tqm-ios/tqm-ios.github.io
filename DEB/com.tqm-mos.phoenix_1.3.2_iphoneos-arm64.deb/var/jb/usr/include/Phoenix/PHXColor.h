#import <UIKit/UIKit.h>

@interface PHXColor : NSObject
+ (UIColor *)dominantColor:(UIImage *)image;
+ (UIColor *)oppositeColor:(UIColor *)color;
+ (UIColor *)primaryColor:(UIImage *)image;
+ (UIColor *)randomColor;
+ (UIColor *)secondaryColor:(UIImage *)image;
+ (UIColor *)textColor:(UIColor *)color;
@end