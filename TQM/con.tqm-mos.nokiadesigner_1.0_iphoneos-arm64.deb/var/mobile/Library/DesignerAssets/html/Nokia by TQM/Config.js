var QuangMinh = "😉•I Love Apple•❤️"; // Tuỳ chọn ký tự.
var QuangMinh1 = "Menu"; // Tuỳ chọn ký tự.
var QuangMinh2 = "Chọn"; // Tuỳ chọn ký tự.
