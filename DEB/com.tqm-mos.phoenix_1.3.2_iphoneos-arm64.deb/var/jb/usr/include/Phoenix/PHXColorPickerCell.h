#import <Preferences/PSSpecifier.h>
#import <Preferences/PSTableCell.h>
#import "PHXColorUtils.h"
#import "PHXColor.h"

@interface UIView (Private)
- (UIViewController *)_viewControllerForAncestor;
@end

@interface PSSpecifier (Private)
- (id)performGetter;
- (void)performSetterWithValue:(id)value;
@end

@interface PHXColorPickerCell : PSTableCell <UIColorPickerViewControllerDelegate>
@property (nonatomic, retain) UIColorPickerViewController *colorPicker;
@property (nonatomic, retain) CAShapeLayer *indicatorShape;
@property (nonatomic, retain) UIView *indicatorView;
@property (nonatomic, retain) UIColor *currentColor;
@property (nonatomic, retain) NSString *fallbackHex;
@end