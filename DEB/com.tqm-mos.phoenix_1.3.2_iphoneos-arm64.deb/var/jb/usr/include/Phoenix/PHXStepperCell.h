#import <Preferences/PSControlTableCell.h>
#import <Preferences/PSSpecifier.h>

@interface PSSpecifier (PHXStepperCell)
- (id)performGetter;
- (void)performSetterWithValue:(id)value;
@end

@interface PHXStepperCell : PSControlTableCell {
	UILabel *_stepperLabel;
	UILabel *_valueLabel;
	UIStackView *_controlStackView;
}
@end