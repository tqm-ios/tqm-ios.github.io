#import <Preferences/PSViewController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <rootless.h>

@interface PHXViewController : PSViewController <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, assign) NSString *defaultsPath;
@property (nonatomic, assign) NSString *prefsPath;
@property (nonatomic, assign) NSMutableDictionary *settings;
@property (nonatomic, assign) NSString *key;
@end