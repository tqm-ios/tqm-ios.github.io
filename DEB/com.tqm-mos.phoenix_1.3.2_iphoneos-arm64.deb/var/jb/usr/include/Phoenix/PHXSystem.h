#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface PHXSystem : NSObject
+ (CGFloat)batteryLevel;
+ (NSString *)batteryState;
@end