#import <MobileCoreServices/MobileCoreServices.h>
#import <Preferences/PSSpecifier.h>
#import <Preferences/PSTableCell.h>
#import <Photos/Photos.h>

@interface UIView (Private)
- (UIViewController *)_viewControllerForAncestor;
@end

@interface PSSpecifier (Private)
- (id)performGetter;
- (void)performSetterWithValue:(id)value;
@end

@interface PHXImagePickerCell : PSTableCell <UINavigationControllerDelegate, UIImagePickerControllerDelegate>
@property (nonatomic, retain) UIImagePickerController *imagePicker;
@property (nonatomic, retain) UIImageView *indicatorView;
@end