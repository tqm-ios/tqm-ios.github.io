#import <Preferences/PSSwitchTableCell.h>
#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import "PHXImagePickerCell.h"
#import "PHXIconLinkCell.h"
#import "PHXPreferences.h"
#import "PHXStepperCell.h"
#import "PHXTwitterCell.h"
#import "PHXBannerView.h"
#import "PHXSliderCell.h"
#import "PHXPowerUtils.h"
#import "PHXGithubCell.h"
#import "PHXCreditCell.h"
#import <UIKit/UIKit.h>
#import "PHXDevice.h"
#import <rootless.h>

@interface PHXListController : PSListController {
	NSMutableArray *allSpecifiers;
}
- (void)applyModificationsToSpecifiers:(NSMutableArray *)specifiers;
- (void)removeDynamicGroups:(NSMutableArray *)specifiers;
- (void)removeDynamicSpecifiers:(NSMutableArray *)specifiers;
- (void)updateDynamicSpecifier:(PSSpecifier *)specifier;
- (void)updateDynamicGroups:(NSMutableArray *)specifiers;
@end