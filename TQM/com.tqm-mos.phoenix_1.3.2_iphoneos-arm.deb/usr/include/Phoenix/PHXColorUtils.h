#import <UIKit/UIKit.h>

@interface PHXColorUtils : NSObject
+ (UIColor *)colorFromHex:(NSString *)hex;
+ (NSString *)hexFromColor:(UIColor *)color;
+ (UIColor *)colorFromImage:(UIImage *)image dimension:(int)dimension flexibility:(int)flexibility range:(int)range;
@end