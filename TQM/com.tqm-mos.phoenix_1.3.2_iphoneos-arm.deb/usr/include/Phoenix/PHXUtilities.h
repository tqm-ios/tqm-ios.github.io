#import <Foundation/Foundation.h>
#import <CoreText/CoreText.h>
#import <UIKit/UIKit.h>
#import <rootless.h>

@interface PHXUtilities : NSObject
+ (CGSize)expectedLabelSize:(UILabel *)label;
+ (NSString *)timeWithFormat:(NSString *)format;
+ (NSString *)dateWithFormat:(NSString *)format;
+ (NSString *)fontWithPath:(NSString *)fontPath;
@end